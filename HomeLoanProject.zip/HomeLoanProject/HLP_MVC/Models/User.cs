﻿namespace HLP_MVC.Models
{
    public class User
    {
        public string UserId { get; set; }
        public string UserName { get; set; }

        public string password { get; set; }

        public string Address { get; set; }

        public string City { get; set; }

        public string State { get; set; }

        public int ZipCode { get; set; }

        public string PANNumber { get; set; }

        public long PhoneNumber { get; set; }

        public long AlternateNumber { get; set; }

        public string CitizenShip { get; set; }

        public string SelfEmployement { get; set; }

        public string CurrentEmployer { get; set; }

        public double CurrentIncome { get; set; }

    }
}
