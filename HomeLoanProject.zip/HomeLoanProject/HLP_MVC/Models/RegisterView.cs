﻿using System.ComponentModel.DataAnnotations;

namespace HLP_MVC.Models
{
    public class RegisterView
    {
        [Required]
        public string UserId { get; set; }
        [Required]
        public string UserName { get; set; }
        [Required]

        public string password { get; set; }
        [Required]

        public string Address { get; set; }
        [Required]

        public string City { get; set; }
        [Required]

        public string State { get; set; }
        [Required]

        public int ZipCode { get; set; }
        [Required]

        public string PANNumber { get; set; }
        [Required]

        public long PhoneNumber { get; set; }
        [Required]

        public long AlternateNumber { get; set; }
        [Required]

        public string CitizenShip { get; set; }
        [Required]

        public string SelfEmployement { get; set; }
        [Required]

        public string CurrentEmployer { get; set; }
        [Required]

        public double CurrentIncome { get; set; }

    }
}
