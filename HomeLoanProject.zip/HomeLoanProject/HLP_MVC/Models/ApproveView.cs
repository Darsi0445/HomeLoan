﻿using System.ComponentModel.DataAnnotations;
namespace HLP_MVC.Models
{
    public class ApproveView
    {
        public int ApproveId { get; set; }
        [Required]
        public int? LoanId { get; set; }
        [Required]
        public virtual Loan? Loan { get; set; }
        [Required]
        public string? EmailId { get; set; }
        [Required]

        public string PropertyName { get; set; }
        [Required]

        public string PropertyDescription { get; set; }
        [Required]

        public string ProprtyAddress { get; set; }
        [Required]

        public int EstimatedCost { get; set; }
        [Required]

        public double LoanAmountRequested { get; set; }
        [Required]

        public bool LoanStatus { get; set; }

        [Required]
        public int? DocumentId { get; set; }

    }
}
