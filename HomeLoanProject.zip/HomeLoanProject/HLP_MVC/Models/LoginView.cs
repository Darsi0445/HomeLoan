﻿using System.ComponentModel.DataAnnotations;

namespace HLP_MVC.Models
{
    public class LoginView
    {
        public int LoginId { get; set; }
        [Required]
        public string EmailId { get; set; }
        [Required]
        [DataType(DataType.Password)]
        public string Password { get; set; }
    }
}
