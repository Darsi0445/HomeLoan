﻿using System.ComponentModel.DataAnnotations;

namespace HLP_MVC.Models
{
    public class Documents
    {
        public int DocumentId { get; set; }
        [Required]
        public string? EmailId { get; set; }
        [Required]

        public string DocumentName { get; set; }
        [Required]

        public string DocumentDescription { get; set; }
    }
}
