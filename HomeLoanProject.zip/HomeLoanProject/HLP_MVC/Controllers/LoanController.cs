﻿using HLP_MVC.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Text;

namespace HLP_MVC.Controllers
{
    public class LoanController : Controller
    {
        private readonly ILogger<LoanController> _logger;

        public LoanController(ILogger<LoanController> logger)

        {

            _logger = logger;

        }
      

        public IActionResult Login()

        {

            return View();

        }

        [HttpPost]

        public async Task<IActionResult> Login(LoginView l)

        {

            try

            {

                if (ModelState.IsValid)

                {

                    using (var httpClient = new HttpClient())

                    {

                        StringContent content = new StringContent(JsonConvert.SerializeObject(l), Encoding.UTF8, "application/json");

                        using (var response = await httpClient.PostAsync("https://localhost:44330/api/Loan/adminlogin", content))

                        {

                            if (response.IsSuccessStatusCode)

                            {

                                HttpContext.Session.SetString("Email", l.EmailId);

                                 

                                return RedirectToAction("Index");

                            }

                        }

                    }

                }

                return View();

            }

            catch (Exception ex)

            {

                return RedirectToAction("Error");

            }

        }

        public IActionResult Register()

        {

            return View();

        }

        [HttpPost]

        public async Task<IActionResult> Register(RegisterView r)

        {

            try

            {

                if (ModelState.IsValid)

                {

                    using (var httpClient = new HttpClient())

                    {

                        StringContent content = new StringContent(JsonConvert.SerializeObject(r), Encoding.UTF8, "application/json");

                        using (var response = await httpClient.PostAsync("https://localhost:44330/api/Loan/Register", content))

                        {

                            if (response.IsSuccessStatusCode)

                            {

                                return RedirectToAction("Login");

                            }

                        }

                    }

                }

                return View();

            }

            catch (Exception ex)

            {

                return RedirectToAction("Error");

            }

        }

        public IActionResult Index()
        {
            return View();
        }

        public async Task<IActionResult> Accept(int id)
        {
            try

            {

              

                using (var httpClient = new HttpClient())

                {

                    using (var response = await httpClient.GetAsync("https://localhost:44330/api/Loan/accept/" + id))

                    {

                        if (response.IsSuccessStatusCode)
                        {
                            return RedirectToAction("Success");
                        }

                    }

                }

                return View();

            }

            catch (Exception ex)

            {

                return RedirectToAction("Error");

            }
        }
        public IActionResult Success()
        {
            return View();
        }
        public async Task<IActionResult> Reject(int id)
        {
            try

            {



                using (var httpClient = new HttpClient())

                {

                    using (var response = await httpClient.GetAsync("https://localhost:44330/api/Loan/reject/" + id))

                    {

                        if (response.IsSuccessStatusCode)
                        {
                            return RedirectToAction("Fail");
                        }

                    }

                }

                return View();

            }

            catch (Exception ex)

            {

                return RedirectToAction("Error");

            }
        }
        public IActionResult Fail()
        {
            return View();
        }

        public async  Task<IActionResult> Requests()
        {
            try

            {

                List<Loan> l = new List<Loan>();

                using (var httpClient = new HttpClient())

                {

                    using (var response = await httpClient.GetAsync("https://localhost:44330/api/Loan/requests"))

                    {

                        var apiResponse = await response.Content.ReadAsStringAsync();

                        l = JsonConvert.DeserializeObject<List<Loan>>(apiResponse);

                    }

                }



                return View(l);

            }

            catch (Exception ex)

            {

                return RedirectToAction("Error");

            }
        }
        public async Task<IActionResult> App()
        {
            try

            {

                List<ApproveView> l = new List<ApproveView>();

                using (var httpClient = new HttpClient())

                {

                    using (var response = await httpClient.GetAsync("https://localhost:44330/api/Loan/app"))

                    {

                        var apiResponse = await response.Content.ReadAsStringAsync();

                        l = JsonConvert.DeserializeObject<List<ApproveView>>(apiResponse);

                    }

                }



                return View(l);

            }

            catch (Exception ex)

            {

                return RedirectToAction("Error");

            }
        }
        public async Task<IActionResult> Rej()
        {
            try

            {

                List<RejectView> l = new List<RejectView>();

                using (var httpClient = new HttpClient())

                {

                    using (var response = await httpClient.GetAsync("https://localhost:44330/api/Loan/rej"))

                    {

                        var apiResponse = await response.Content.ReadAsStringAsync();

                        l = JsonConvert.DeserializeObject<List<RejectView>>(apiResponse);

                    }

                }



                return View(l);

            }

            catch (Exception ex)

            {

                return RedirectToAction("Error");

            }
        }
        public IActionResult SearchBar()
        {
            return View();
        }
        public async Task<IActionResult> Search(int id)
        {
        
            try

            {

                Loan b = null;

                using (var httpClient = new HttpClient())

                {

                    using (var response = await httpClient.GetAsync("https://localhost:44330/api/Loan/getloan/" + id))

                    {

                        var apiResponse = await response.Content.ReadAsStringAsync();

                        b = JsonConvert.DeserializeObject<Loan>(apiResponse);

                    }

                }

                return View(b);

            }

            catch (Exception ex)

            {

                return RedirectToAction("Error");

            }
        }


        public IActionResult Logout()

        {

            HttpContext.Session.Clear();

            return RedirectToAction("Index","Home");

        }

    }
}
