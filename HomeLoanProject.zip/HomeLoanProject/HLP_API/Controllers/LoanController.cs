﻿using HLP_API.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Win32;
using System;

namespace HLP_API.Controllers
{
    [Route("api/[controller]")]

    [ApiController]
    public class LoanController : Controller
    {

        LoanDbContext db = null;

        public LoanController(LoanDbContext context)

        {

            db = context;

        }

        [HttpPost]
        [Route("Register")]

        public IActionResult Register([FromBody] RegisterView r)

        {

            if (r == null)

            {

                return BadRequest();

            }

            else

            {

                User u = new User();
                u.UserId = r.UserId;
                u.UserName = r.UserName;
                u.password = r.password;
                u.Address = r.Address;
                u.City = r.City;
                u.State = r.State;
                u.ZipCode = r.ZipCode;
                u.PANNumber = r.PANNumber;
                u.PhoneNumber = r.PhoneNumber;
                u.AlternateNumber = r.AlternateNumber;
                u.CitizenShip = r.CitizenShip;
                u.SelfEmployement = r.SelfEmployement;
                u.CurrentEmployer = r.CurrentEmployer;
                u.CurrentIncome = r.CurrentIncome;

                db.Users.Add(u);
                db.SaveChanges();

                return Ok(u);

            }

        }

        [HttpPost]

        [Route("adminlogin")]

        public IActionResult Login([FromBody] LoginView l)

        {

            if (l == null)

            {

                return BadRequest();

            }

            var admin = (from c in db.Users

                            where (c.UserId == l.EmailId && c.password == l.Password)&&(l.EmailId=="admin@wipro.com" && l.Password=="vamsi@123")

                            select c).SingleOrDefault();

            if (admin == null)

            {

                return BadRequest();

            }

            else

            {
                l.EmailId = admin.UserId;
                l.Password = admin.password;
                db.Login.Add(l);
                 

                db.SaveChanges();

                return Ok();

            }

        }

        [HttpGet]
        [Route("requests")]
        public IActionResult Requests()
        {
            var req = from l in db.Loan
                      where l.LoanStatus == false
                      select l;
            return Ok(req.ToList());
        }
        [HttpGet]
        [Route("requestbyid/{id}")]
        public IActionResult ById(int id)
        {
            var req = db.Loan.Find(id);
            return Ok(req);
        }
       
        [HttpGet]
        [Route("accept/{id}")]
        public IActionResult Accept(int id)
        {
            var loan = (from l in db.Loan
                        where l.LoanId == id
                        select l).SingleOrDefault();
            loan.LoanStatus = true;
            Approve a = new Approve();
            a.LoanId = loan.LoanId;
            a.EmailId = loan.EmailId;
            a.PropertyName = loan.PropertyName;
            a.PropertyDescription = loan.PropertyDescription;
            a.ProprtyAddress = loan.ProprtyAddress;
            a.EstimatedCost = loan.EstimatedCost;
            a.LoanAmountRequested = loan.LoanAmountRequested;
            a.LoanStatus = loan.LoanStatus;
           
            db.Approves.Add(a);
            //db.Loan.Remove(loan);
            db.SaveChanges();
            return Ok();
        }
        [HttpGet]
        [Route("reject/{id}")]
        public IActionResult Reject(int id)
        {
            var loan = (from l in db.Loan
                        where l.LoanId == id
                        select l).SingleOrDefault();
         
            Reject a = new Reject();
            a.LoanId = loan.LoanId;
            a.EmailId = loan.EmailId;
            a.PropertyName = loan.PropertyName;
            a.PropertyDescription = loan.PropertyDescription;
            a.ProprtyAddress = loan.ProprtyAddress;
            a.EstimatedCost = loan.EstimatedCost;
            a.LoanAmountRequested = loan.LoanAmountRequested;
            a.LoanStatus = loan.LoanStatus;
            a.DocumentId = loan.DocumentId;
            db.Rejects.Add(a);
           db.Loan.Remove(loan);
            db.SaveChanges();
            return Ok();
        }
        [HttpGet]
        [Route("app")]
        public IActionResult App()
        {
            var app = from a in db.Approves
                      select a;
            return Ok(app.ToList());
        }
        [HttpGet]
        [Route("rej")]
        public IActionResult Rej()
        {
            var app = from a in db.Rejects
                      select a;
            return Ok(app.ToList());
        }
        [HttpGet]
        [Route("getloan/{id}")]
        public IActionResult Loan(int id)
        {
            var loan = (from l in db.Loan
                        where l.LoanId == id
                        select l).SingleOrDefault();
            return Ok(loan);
        }
    }
}
