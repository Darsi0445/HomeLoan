﻿using System.ComponentModel.DataAnnotations;
namespace HLP_API.Models
{
    public class Documents
    {
        [Key]
        public int DocumentId { get; set; }
        public string? EmailId { get; set; }

        public string DocumentName { get; set; }

        public string DocumentDescription { get; set; }

        public virtual User? customer { get; set; }

    }
}
