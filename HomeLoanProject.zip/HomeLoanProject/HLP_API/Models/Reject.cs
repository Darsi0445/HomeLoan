﻿using System.ComponentModel.DataAnnotations;

namespace HLP_API.Models
{
    public class Reject
    {
        [Key]
        public int RejectId { get; set; }
        public int? LoanId { get; set; }
        public virtual Loan? Loan { get; set; }
        public string? EmailId { get; set; }

        public string PropertyName { get; set; }

        public string PropertyDescription { get; set; }

        public string ProprtyAddress { get; set; }

        public int EstimatedCost { get; set; }

        public double LoanAmountRequested { get; set; }

        public bool LoanStatus { get; set; }
        public int? DocumentId { get; set; }

        public virtual List<Documents>? Documents { get; set; }

        public virtual User? Customer { get; set; }
    }
}
