﻿using System.ComponentModel.DataAnnotations;

namespace HLP_API.Models
{
    public class LoginView
    {
        [Key]
        public int LoginId { get; set; }
        public string EmailId { get; set; }
        public string Password { get; set; }
    }
}
