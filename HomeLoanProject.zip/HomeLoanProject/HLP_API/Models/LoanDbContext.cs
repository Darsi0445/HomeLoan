﻿using Microsoft.EntityFrameworkCore;

namespace HLP_API.Models
{
    public class LoanDbContext:DbContext
    {
        public LoanDbContext(DbContextOptions<LoanDbContext> options) : base(options)
        {

        }
        public virtual DbSet<User> Users { get; set; }


        public virtual DbSet<LoginView> Login { get; set; }
        public virtual DbSet<Documents> Documents { get; set; }

        public virtual DbSet<Loan> Loan { get; set; }

        public virtual DbSet<Approve> Approves { get; set; }
        public virtual DbSet<Reject> Rejects { get; set; }
    }
}
