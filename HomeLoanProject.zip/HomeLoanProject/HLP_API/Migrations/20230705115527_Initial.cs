﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace HLP_API.Migrations
{
    public partial class Initial : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Login",
                columns: table => new
                {
                    LoginId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    EmailId = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Password = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Login", x => x.LoginId);
                });

            migrationBuilder.CreateTable(
                name: "Users",
                columns: table => new
                {
                    UserId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    UserName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    password = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Address = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    City = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    State = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ZipCode = table.Column<int>(type: "int", nullable: false),
                    PANNumber = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PhoneNumber = table.Column<long>(type: "bigint", nullable: false),
                    AlternateNumber = table.Column<long>(type: "bigint", nullable: false),
                    CitizenShip = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    SelfEmployement = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CurrentEmployer = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CurrentIncome = table.Column<double>(type: "float", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Users", x => x.UserId);
                });

            migrationBuilder.CreateTable(
                name: "Loan",
                columns: table => new
                {
                    LoanId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    EmailId = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PropertyName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PropertyDescription = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ProprtyAddress = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    EstimatedCost = table.Column<int>(type: "int", nullable: false),
                    LoanAmountRequested = table.Column<double>(type: "float", nullable: false),
                    LoanStatus = table.Column<bool>(type: "bit", nullable: false),
                    DocumentId = table.Column<int>(type: "int", nullable: true),
                    CustomerUserId = table.Column<string>(type: "nvarchar(450)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Loan", x => x.LoanId);
                    table.ForeignKey(
                        name: "FK_Loan_Users_CustomerUserId",
                        column: x => x.CustomerUserId,
                        principalTable: "Users",
                        principalColumn: "UserId");
                });

            migrationBuilder.CreateTable(
                name: "Approves",
                columns: table => new
                {
                    ApproveId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    LoanId = table.Column<int>(type: "int", nullable: true),
                    EmailId = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PropertyName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PropertyDescription = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ProprtyAddress = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    EstimatedCost = table.Column<int>(type: "int", nullable: false),
                    LoanAmountRequested = table.Column<double>(type: "float", nullable: false),
                    LoanStatus = table.Column<bool>(type: "bit", nullable: false),
                    DocumentId = table.Column<int>(type: "int", nullable: true),
                    CustomerUserId = table.Column<string>(type: "nvarchar(450)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Approves", x => x.ApproveId);
                    table.ForeignKey(
                        name: "FK_Approves_Loan_LoanId",
                        column: x => x.LoanId,
                        principalTable: "Loan",
                        principalColumn: "LoanId");
                    table.ForeignKey(
                        name: "FK_Approves_Users_CustomerUserId",
                        column: x => x.CustomerUserId,
                        principalTable: "Users",
                        principalColumn: "UserId");
                });

            migrationBuilder.CreateTable(
                name: "Rejects",
                columns: table => new
                {
                    RejectId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    LoanId = table.Column<int>(type: "int", nullable: true),
                    EmailId = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PropertyName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PropertyDescription = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ProprtyAddress = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    EstimatedCost = table.Column<int>(type: "int", nullable: false),
                    LoanAmountRequested = table.Column<double>(type: "float", nullable: false),
                    LoanStatus = table.Column<bool>(type: "bit", nullable: false),
                    DocumentId = table.Column<int>(type: "int", nullable: true),
                    CustomerUserId = table.Column<string>(type: "nvarchar(450)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Rejects", x => x.RejectId);
                    table.ForeignKey(
                        name: "FK_Rejects_Loan_LoanId",
                        column: x => x.LoanId,
                        principalTable: "Loan",
                        principalColumn: "LoanId");
                    table.ForeignKey(
                        name: "FK_Rejects_Users_CustomerUserId",
                        column: x => x.CustomerUserId,
                        principalTable: "Users",
                        principalColumn: "UserId");
                });

            migrationBuilder.CreateTable(
                name: "Documents",
                columns: table => new
                {
                    DocumentId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    EmailId = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DocumentName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    DocumentDescription = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    customerUserId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    ApproveId = table.Column<int>(type: "int", nullable: true),
                    LoanId = table.Column<int>(type: "int", nullable: true),
                    RejectId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Documents", x => x.DocumentId);
                    table.ForeignKey(
                        name: "FK_Documents_Approves_ApproveId",
                        column: x => x.ApproveId,
                        principalTable: "Approves",
                        principalColumn: "ApproveId");
                    table.ForeignKey(
                        name: "FK_Documents_Loan_LoanId",
                        column: x => x.LoanId,
                        principalTable: "Loan",
                        principalColumn: "LoanId");
                    table.ForeignKey(
                        name: "FK_Documents_Rejects_RejectId",
                        column: x => x.RejectId,
                        principalTable: "Rejects",
                        principalColumn: "RejectId");
                    table.ForeignKey(
                        name: "FK_Documents_Users_customerUserId",
                        column: x => x.customerUserId,
                        principalTable: "Users",
                        principalColumn: "UserId");
                });

            migrationBuilder.CreateIndex(
                name: "IX_Approves_CustomerUserId",
                table: "Approves",
                column: "CustomerUserId");

            migrationBuilder.CreateIndex(
                name: "IX_Approves_LoanId",
                table: "Approves",
                column: "LoanId");

            migrationBuilder.CreateIndex(
                name: "IX_Documents_ApproveId",
                table: "Documents",
                column: "ApproveId");

            migrationBuilder.CreateIndex(
                name: "IX_Documents_customerUserId",
                table: "Documents",
                column: "customerUserId");

            migrationBuilder.CreateIndex(
                name: "IX_Documents_LoanId",
                table: "Documents",
                column: "LoanId");

            migrationBuilder.CreateIndex(
                name: "IX_Documents_RejectId",
                table: "Documents",
                column: "RejectId");

            migrationBuilder.CreateIndex(
                name: "IX_Loan_CustomerUserId",
                table: "Loan",
                column: "CustomerUserId");

            migrationBuilder.CreateIndex(
                name: "IX_Rejects_CustomerUserId",
                table: "Rejects",
                column: "CustomerUserId");

            migrationBuilder.CreateIndex(
                name: "IX_Rejects_LoanId",
                table: "Rejects",
                column: "LoanId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Documents");

            migrationBuilder.DropTable(
                name: "Login");

            migrationBuilder.DropTable(
                name: "Approves");

            migrationBuilder.DropTable(
                name: "Rejects");

            migrationBuilder.DropTable(
                name: "Loan");

            migrationBuilder.DropTable(
                name: "Users");
        }
    }
}
